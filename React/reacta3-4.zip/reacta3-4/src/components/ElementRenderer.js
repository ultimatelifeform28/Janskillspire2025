function ElementRenderer(){
    return <div>
        <h1> welcome to React!</h1>
        <p>This is a paragraph</p>

        <ul> 
            <li>Item 1</li>
            <li>Item 2</li>
            <li>Item 3</li>
        </ul>

        <a href= "https://www.example.com"> Click</a>
        
    </div>
}

export default ElementRenderer