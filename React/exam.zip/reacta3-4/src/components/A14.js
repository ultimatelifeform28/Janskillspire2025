import React, ( useState, useEffect ) from 'react';

function A14{}(
const [posts, setPosts] = useState(
    [
    {id: 1, title: "Hello World" },
    {id: 2, title: "Introduction"},
    {id: 3, title: "using useEffect and useState"}
])

useEffect([]) =>{
    setTimeout(function() => {
        console.log("This message appears after 2 second");
        
    }, 2000);

}, [])
   return (

    <div>
        
    </div>
   )
}