import React from 'react';
import PostManager from './components/PostManager';

function App() {
  return (
    <div>
      <h1>Post </h1>
      <PostManager />
    </div>
  );
}

export default App;
