const UserProfilePosts = () => {
  return (
    <>
      <div>User Profile Posts</div>
      <div>I’m happy to share that I’ve started my Bootcamp at Skillspire!</div>
    </>
  );
};

export default UserProfilePosts;