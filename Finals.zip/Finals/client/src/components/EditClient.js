import React, { useState, useEffect } from 'react';
import {getClient,updateClient } from '../API/api';
import { useParams, useNavigate } from 'react-router-dom';
import './AddClient.css'; // Reuse same styles as AddClient

function EditClient() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    gender: '',
    short_term_goal: '',
    long_term_goal: '',
    current_weight: '',
    target_weight: '',
    height: '',
    age: '',
    activity_level: '',
    diet_type: '',
    allergies: '',
    medical_conditions: '',
    meal_plan: '',
    workout_plan: '',
    progress: ''
  });

  // Load existing client data
  useEffect(() => {
  getClient()
    .then(res => {
      const client = res.data.find(c => c.id === parseInt(id));
      if (client) {
        setForm(client);
      } else {
        alert("Client not found");
        navigate('/');
      }
    })
    .catch(err => console.error("Failed to fetch client", err));
}, [id, navigate]);
   

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
  e.preventDefault();
  updateClient(id, form)
    .then(() => {
      alert("Client updated successfully!");
      navigate('/');
    })
    .catch(err => {
      console.error("Error updating client", err);
      alert("Failed to update client.");
    });
};

  return (
    <form onSubmit={handleSubmit} className="client-form">
      <h2>Edit Client</h2>
      {Object.keys(form).map((key) => (
        <div key={key}>
          <label>{key.replace(/_/g, ' ').toUpperCase()}</label>
          <input
            type="text"
            name={key}
            value={form[key]}
            onChange={handleChange}
            required={['name', 'email', 'phone', 'gender'].includes(key)}
          />
        </div>
      ))}
      <button type="submit">Update Client</button>
    </form>
  );
}

export default EditClient;
