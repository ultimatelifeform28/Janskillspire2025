import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome to React!</h1>
      <p>First Name: Ja'Corey</p>
      <p>Last Name: Lasane</p>
      <p>Favorite Food: Pizza</p>
      <p>Favorite Vacation Destination: Japan </p>
    </div>
  );
}

export default App;
