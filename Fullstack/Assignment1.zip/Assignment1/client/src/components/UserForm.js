import React from 'react';
import { useState } from 'react';

const UserForm = ({ onCreate }) => {
  const [name, setName] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [dietary, setDietary] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onCreate({ name, height, weight, dietary });
    setName('');
    setHeight('');
    setWeight('');
    setDietary('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create User</h2>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder={'Height (e.g. 5\'6")'}
        value={height}
        onChange={(e) => setHeight(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Weight"
        value={weight}
        onChange={(e) => setWeight(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Dietary"
        value={dietary}
        onChange={(e) => setDietary(e.target.value)}
        required
      />
      <button type="submit">Create User</button>
    </form>
  );
}

export default UserForm;