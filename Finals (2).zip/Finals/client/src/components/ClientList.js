import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ClientList.css';

function ClientLists() {
  const [client, setClient] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5002/clients')
      .then(res => setClient(res.data))
      .catch(err => console.error("Error fetching clients:", err));
  }, []);

  return (
    <div className="client-list">
      <h1>Client Dashboard</h1>
      {client.length === 0 ? (
        <p>No clients available.</p>
      ) : (
        client.map(client => (
          <div className="client-card" key={client.id}>
            <h2>{client.name}</h2>
            <p><strong>Email:</strong> {client.email}</p>
            <p><strong>Phone:</strong> {client.phone}</p>
            <p><strong>Gender:</strong> {client.gender}</p>
            <p><strong>Age:</strong> {client.age}</p>
            <p><strong>Weight:</strong> {client.current_weight} ➡ {client.target_weight} lbs</p>
            <p><strong>Height:</strong> {client.height} cm</p>
            <p><strong>Short-Term Goal:</strong> {client.short_term_goal}</p>
            <p><strong>Long-Term Goal:</strong> {client.long_term_goal}</p>
            <p><strong>Activity Level:</strong> {client.activity_level}</p>
            <p><strong>Diet:</strong> {client.diet_type}</p>
            <p><strong>Allergies:</strong> {client.allergies}</p>
            <p><strong>Medical Conditions:</strong> {client.medical_conditions}</p>
            <p><strong>Workout Plan:</strong> {client.workout_plan}</p>
            <p><strong>Meal Plan:</strong> {client.meal_plan}</p>
            <p><strong>Progress:</strong> {client.progress}</p>
          </div>
        ))
      )}
    </div>
  );
}

export default ClientLists;