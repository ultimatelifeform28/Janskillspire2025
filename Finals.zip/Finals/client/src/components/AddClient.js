import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addClient } from '../API/api';
import './AddClient.css';

function AddClient() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    gender: '',
    short_term_goal: '',
    long_term_goal: '',
    current_weight: '',
    target_weight: '',
    height: '',
    age: '',
    activity_level: '',
    diet_type: '',
    medical_conditions: '',
    allergies: '',
    meal_plan: '',
    workout_plan: '',
    progress: ''
  });

  const navigate = useNavigate();
  const requiredFields = ['name', 'email', 'phone', 'gender'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addClient(form);
      navigate('/');
    } catch (error) {
      console.error("There was an error adding the client!", error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="client-form">
      <h2>Add New Client</h2>
      {Object.keys(form).map((key) => (
        <div key={key}>
          <label>{key.replace(/_/g, ' ').toUpperCase()}</label>
          <input
            type={['age', 'current_weight', 'target_weight', 'height'].includes(key) ? 'number' : 'text'}
            name={key}
            value={form[key]}
            onChange={handleChange}
            required={requiredFields.includes(key)}
          />
        </div>
      ))}
      <button type="submit">Submit</button>
    </form>
  );
}

export default AddClient;
