function Vacation(){
    return (
        <div className="vacation">
            <h1>Japan</h1>
            <p>Plan your next vacation with us!</p>
            <img src= "https://th.bing.com/th/id/OIP.bSnTokC_c4OMgm-bm9OfyQHaE2?w=309&h=202&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2" alt="Japan" />
                </div>
            );
        }
        

 export default Vacation;  