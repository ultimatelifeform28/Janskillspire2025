//import logo from './logo.svg';
import './App.css';
//import ElementRenderer from './components/ElementRenderer';
//import ParentComponent from './components/ParentComponent';
//import EventHandling from './components/EventHandling';
//import RenderingList from './components/RenderingList';
//import ConditionalRenderer from './components/ConditionalRenderer';
import A11 from './components/A11';
import A12 from './components/A12';
import Timer from './components/Timer';





function App() {
  return (
    <div className="App">
      <A11 />
      <h1>Conditional Rendering</h1>
      <A12 />
      <h1>Timer</h1>
      <Timer />

    </div>
  );
}

export default App;
