function Food(){
    return (
        <div className="vacation">
            <h1>Tuna Poke</h1>
            <p>Plan your next vacation with us!</p>
            <img src= "https://bondibeauty.com.au/wp-content/uploads/2017/04/poke.jpeg" alt="Poke bowel" />
                </div>
            );
        }
        

 export default Food;  