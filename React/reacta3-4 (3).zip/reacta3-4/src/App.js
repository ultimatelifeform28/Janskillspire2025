//import logo from './logo.svg';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Student from './components/Student'; // Importing the Student component
import Students from './components/Students';

//import ElementRenderer from './components/ElementRenderer';
//import ParentComponent from './components/ParentComponent';
//import EventHandling from './components/EventHandling';
//import RenderingList from './components/RenderingList';
//import ConditionalRenderer from './components/ConditionalRenderer';
//import A11 from './components/A11';
//import A12 from './components/A12';
//import Timer from './components/Timer';
//import Food from './components/Food';
//import Vacation from './components/Vacation';






function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Students />} />
        <Route path="/item/:id" element={<Student />} />
        
      </Routes>
    </Router>
  );
}

export default App;
