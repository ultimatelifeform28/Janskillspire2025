//import logo from './logo.svg';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

//import ElementRenderer from './components/ElementRenderer';
//import ParentComponent from './components/ParentComponent';
//import EventHandling from './components/EventHandling';
//import RenderingList from './components/RenderingList';
//import ConditionalRenderer from './components/ConditionalRenderer';
//import A11 from './components/A11';
//import A12 from './components/A12';
//import Timer from './components/Timer';
import Food from './components/Food';
import Vacation from './components/Vacation';






function App() {
  return (
    <Router>
      <Routes>
        <Route path="/home" element={<h1>Home</h1>} />
        <Route path="/display_name" element={<h1>Display</h1>} />
        <Route path="/display_Food" element={ <Food />} />
        <Route path="/display_Vacation" element={<Vacation />} />
      </Routes>
    </Router>
  );
}

export default App;
