import logo from './logo.svg';
import './App.css';
import React from 'react';

import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ClientLists from './components/ClientList';
import AddClients from './components/AddClient';
import EditClients from './components/EditClient';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ClientLists />} />
        <Route path="/add" element={<AddClients />} />
        <Route path="/edit/:id" element={<EditClients />} />
      </Routes>
    </Router>
  );
}

export default App;
