//import logo from './logo.svg';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
//import Student from './components/Student'; // Importing the Student component
//import Students from './components/Students';

//import ElementRenderer from './components/ElementRenderer';
//import ParentComponent from './components/ParentComponent';
//import EventHandling from './components/EventHandling';
//import RenderingList from './components/RenderingList';
//import ConditionalRenderer from './components/ConditionalRenderer';
//import A11 from './components/A11';
//import A12 from './components/A12';
//import Timer from './components/Timer';
//import Food from './components/Food';
//import Vacation from './components/Vacation';
//import RandomNumberGenerator from './components/RandomNumberGenerator';
//import Counter from './components/Counter';
//import A14 from './components/A14';
import Login from './components/login';
import Dashboard from './components/Dashboard';






import { useState } from 'react';

function App() {
  const [isAuthenticated, setAuthenticated] = useState(false);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login setAuth={setAuthenticated} />} />
        <Route
          path="/dashboard"
          element={
            isAuthenticated ? (
              <Dashboard />
            ) : (
              <h1>Please log in to access the dashboard</h1>
            )
          }
        />
        <Route path="*" element={<h1>Login</h1>} />y
      </Routes>
    </Router>
  );
}

export default App;
