const UserProfileHeader = () => {
  return <header>User Profile </header>;
};

export default UserProfileHeader;