from flask import Flask, request, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///new_course.db'
db = SQLAlchemy(app) # initialize the database
app.secret_key = 'your secret key'


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # id is the primary key
    course_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/') # Home page
def new_course():
    all_courses = Course.query.all()
    return render_template('new_course.html', all_courses=all_courses)

@app.route('/add_course', methods=["POST"]) # POST request
def add_course():
        course_name = request.form.get("course_name")
        description = request.form.get("description")

        if not course_name or not description:
            flash("Course name and description are required!", "error")
            return redirect(url_for("new_course"))  # redirect to the same page
    
        course = Course(course_name=course_name, description=description)
        db.session.add(course)
        db.session.commit()
        return redirect(url_for("new_course"))
    
@app.route("/courses/delete/confirm/<int:course_id>", methods=["GET"])
def confirm_delete(course_id):
    course = Course.query.get(course_id)
    if not course:
        flash("Course not found", "error")
        return redirect(url_for("new_course"))
    return render_template("delete.html", course=course)
 
@app.route("/courses/delete/<int:course_id>", methods=["POST"])
def delete_course(course_id):
    course = Course.query.get(course_id)
    if not course:
        flash("Course not found", "error")
        return redirect(url_for("new_course"))
    db.session.delete(course)
    db.session.commit()
    flash("Course deleted successfully!", "success")
    return redirect(url_for("new_course"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        print("Database created")
    app.run(debug=True)
